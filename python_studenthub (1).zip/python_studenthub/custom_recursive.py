
def recursive_avg(lst, n=None):
    if n is None:
        n = len(lst)
    if n == 0:
        return 0
    if n == 1:
        return lst[0]
    return (recursive_avg(lst, n-1) * (n-1) + lst[n-1]) / n


def wellness_streak(mood_list, idx=None, threshold=7):
    if idx is None:
        idx = len(mood_list) - 1
    if idx < 0 or mood_list[idx] < threshold:
        return 0
    return 1 + wellness_streak(mood_list, idx - 1, threshold)
