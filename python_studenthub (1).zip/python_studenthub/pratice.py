

# Predefined residents database
residents = {
    101: "Alice",
    102: "Bob",
    201: "Charlie"
}

# List to store visitor/resident entry logs
entry_logs = []

# Tuple for static guard shift times
shifts = ("Morning", "Afternoon", "Night")

# Menu loop
while True:
    print("\nMENU")
    print("1. Log Entry")
    print("2. View All Entry Logs")
    print("3. View Guard Shifts")
    print("4. Exit")

    choice = input("Enter your choice (1–4): ").strip()

    if choice == "1":
        # Log a new entry
        print("\n=== Log Entry ===")

        n= int(input("Enter number of people to log: "))


        for i in range(n):
            print(f"\nEntry {i+1}:")

            # Name validation
            name = input("Enter Name: ").strip()
            while not name.isalpha():
                print("Name must contain only letters.")
                name = input("Enter Name: ").strip()

            # Apartment number validation
            apt = input("Enter Apartment Number: ").strip()
            while not apt.isdigit():
                print("Apartment number must be numeric.")
                apt = input("Enter Apartment Number: ").strip()
            apt = int(apt)

            # Person type validation
            person_type = input("Resident or Visitor? ").strip().lower()
            while person_type not in ["resident", "visitor"]:
                print("Please enter 'Resident' or 'Visitor'")
                person_type = input("Resident or Visitor? ").strip().lower()

            # Purpose of visit
            purpose = input("Purpose of visit: ").strip()

            # Decision control logic
            if person_type == "resident":
                status = "Entry Allowed"
            else:
                if apt in residents:
                    status = "Entry Allowed"
                else:
                    status = "Entry Denied"

            # Store log
            log = {
                "Name": name,
                "Apartment": apt,
                "Type": person_type,
                "Purpose": purpose,
                "Status": status
            }
            entry_logs.append(log)

            status_set = set()
            status_set.add(status)
            print(status_set)

            # Print formatted log
            print(f"Visitor: {name}, Apartment: {apt}, Status: {status}")

    elif choice == "2":
        # Display all entry logs
        print("\n=== All Entry Logs ===")
        if not entry_logs:
            print("No entries logged yet.")
        else:
            for log in entry_logs:
                print(log)

    elif choice == "3":
        # Display guard shifts
        print("\n=== Guard Shifts ===")
        print("Shifts:", shifts)

    elif choice == "4":
        # Exit program
        print("Exiting system.")
        break

    else:
        print("Invalid choice. Please select from the menu.")
