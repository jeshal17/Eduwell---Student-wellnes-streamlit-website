# Smart Fitness Tracker - Inline Version with Comments
import time
text = "Welcome to my project..."
for char in text:
    print(char, end='', flush=True)
    time.sleep(0.05)



import random
# List of quotes
quotes = [
    "The best way to get started is to quit talking and begin doing.",
    "Don’t let yesterday take up too much of today.", 
    "Great things never come from comfort zones."
]

# Pick and print a random quote
quote = random.choice(quotes)
print("\n💡 Quote of the Day:")	
print(quote)

# Initialize storage structures
users = {}                # Dictionary to store user data: UserID -> details
user_names = []           # List to store user names
user_names_tuple = ()     # Tuple version of user_names for tuple operations

# Menu loop
while True:
    # Display menu options
    print("\nMENU")
    print("1. Register Users")
    print("2. Login")
    print("3. List Operations")
    print("4. Tuple Operations")
    print("5. Show User Data")
    print("6. Step Range Analysis")
    print("8. search by id")
    print("7. Exit")

    # Get user choice
    choice = input("Enter your choice (1–7): ")
 
    # Option 1: Register Users
    if choice == "1":
        print("\n=== Registration ===")

        # Register 5 users
        n = int(input("enter the number of users"))
        
        for i in range(n):
            print(f"\nRegister User{i+1}:")

            # Validate UserID (must be unique and integer)
            user_id = input("UserID (integer): ")
            while not user_id.isdigit() or int(user_id) in users:
                print("Invalid or duplicate UserID.")
                user_id = input("UserID (integer): ")
            user_id = int(user_id)

            # Validate Name (alphabetic and non-empty)
            name = input("Name: ")
            while not name.isalpha():
                print("Name must contain only letters.")
                name = input("Name: ")

            # Validate Phone (10-digit number)
            phone = input("Phone (10 digits): ")
            while not (phone.isdigit() and len(phone) == 10):
                print("Phone must be a 10-digit number.")
                phone = input("Phone (10 digits): ")

            # Validate Age (between 10 and 120)
            age = input("Age: ")
            while not (age.isdigit() and 10 <= int(age) <= 120):
                print("Age must be between 10 and 120.")
                age = input("Age: ")
            age = int(age)

            # Validate Steps (positive integer)
            steps = input("Steps Walked (integer): ")
            while not steps.isdigit():
                print("Steps must be a positive integer.")
                steps = input("Steps Walked (integer): ")
            steps = int(steps)

            # Validate Password (minimum 4 characters)
            password = input("Password (min 4 chars): ").strip()
            while len(password) < 4:
                print("Password must be at least 4 characters.")
                password = input("Password (min 4 chars): ").strip()

            # Store user data in dictionary
            users= {
                "userid":user_id,
                "Name": name,
                "Phone": phone,
                "Age": age,
                "Steps": steps,
                "Password": password
            }
  
            # Add name to user_names list
            user_names.append(name)

        print("\nRegistration Completed")

    # Option 2: Login
    elif choice == "2":
        print("\n=== Login ===")
        login_id = input("Enter UserID: ")
        login_password = input("Enter Password: ")

        # Validate login credentials
        while not login_id.isdigit() or int(login_id) not in users or users[int(login_id)]["Password"] != login_password:
            print("Invalid UserID or Password.")
            login_id = input("Enter UserID: ")
            login_password = input("Enter Password: ")

        login_id = int(login_id)
        print(f"\nLogin Successful. Welcome {users[login_id]['Name']}")

    # Option 3: List Operations
    elif choice == "3":
        print("\n=== List Operations ===")
        print("Current User Names:", user_names)

        # Add name at end
        new_name = input("Add a new name at the end: ").strip()
        if new_name.isalpha():
            user_names.append(new_name)

        # Add name at specific position
        pos_name = input("Add another name at a position: ").strip()
        pos = input("Enter position (0-based index): ")
        if pos_name.isalpha() and pos.isdigit():
            pos = int(pos)
            if 0 <= pos <= len(user_names):
                user_names.insert(pos, pos_name)
            else:
                print("Invalid position. Adding at end.")
                user_names.append(pos_name)
        else: 
            print("Invalid input. Adding at end.")
            user_names.append(pos_name)

        # Remove a name
        rem_name = input("Enter a name to remove: ")
        if rem_name in user_names:
            user_names.remove(rem_name)
        else:
            print("Name not found.")

        # Convert list to tuple
        user_names_tuple = tuple(user_names)
        print("Final User Names Tuple:", user_names_tuple)

    # Option 4: Tuple Operations
    elif choice == "4":
        if not user_names_tuple:
            print("No tuple available. Run list operations first.")
        else:
            print("\n=== Tuple Operations ===")
            print("First name:", user_names_tuple[0])
            print("Last name:", user_names_tuple[-1])
            print("Slice [1:4]:", user_names_tuple[1:4])

            # Count and locate a name
            search_name = input("Enter name to count and locate: ").strip()
            #to count the names or users
            count = user_names_tuple.count(search_name)
            print(search_name + "occurs" + count + "times")
            #search in tuple 
            if search_name in user_names_tuple:
                index = user_names_tuple.index(search_name)
                print(f"First occurrence at index {index}.")
            else:
                print("Name not found.")

            # Display all names in tuple
            print("\nAll names in tuple:")
            for name in user_names_tuple:
                print("-", name)

    # Option 5: Show User Data
    elif choice == "5":
        print("\n=== User Data Dictionary ===")
        for key, value in users.items():
            print(f"{key}: {value}")

    # Option 6: Step Range Analysis
    elif choice == "6":
        print("\n=== Unique Step Ranges ===")
        step_ranges = set()
        for u in users.values():
            steps = u["Steps"]
            if steps < 5000:
                step_ranges.add("<5000")
            elif 5000 <= steps < 10000:
                step_ranges.add("5000–9999")
            else:
                step_ranges.add("10000+")

    # Option 7: Exit
    elif choice == "7":
        print("Exiting program.")
        break

    elif choice =="8":
        search_id = input("Enter UserID to search: ")
        if search_id.isdigit() and int(search_id) in users:
         print("Field      | Value")
         print("-------------------")
        for key, value in users[int(search_id)].items():
            print(f"{key:<10} | {value}")
    else:
        print("UserID not found.")

    # Invalid choice
else:
    print("Invalid choice. Try again.")
