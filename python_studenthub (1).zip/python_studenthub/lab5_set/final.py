from fitness_utils import *
import random
import time 
from tabulate import tabulate
e  = "hiii mamama"
for i in e :
    print(i,end="",flush=True)
    time.sleep(.3)
 
quotes = [
    "The best way to get started is to quit talking and begin doing.",
    "Don’t let yesterday take up too much of today.", 
    "Great things never come from comfort zones."
]

quote = random.choice(quotes)
print("\n💡 Quote of the Day:,")	
print(quote)

records = []
metric_keys = ['steps', 'calories', 'hours_slept']

while True:
    print("\n===== FITNESS TRACKER MENU =====")
    print("1. Add Record")
    print("2. Display All Records")
    print("3. Compute Average (of steps)")
    print("4. Show Top Record (sum of steps + calories + hours_slept)")
    print("5. Find Min/Max Record (based on steps)")
    print("6. Filter Records by Threshold (steps)")
    print("7. Search Record by ID")
    print("8. Remove Record by ID")
    print("9. Show Records Sorted by Steps")
    print("10. Show Records in Reverse Order")
    print("11. Exit")

    choice = input("Enter your choice: ").strip()

    if choice == '1':
        record = {}
        rid = int(input("Enter ID (number): "))
        while any(r['id'] == rid for r in records):
            print("Duplicate ID. Try again.")
            rid = int(input("Enter ID (number): "))
        record['id'] = rid

        # Name validation
        name = input("Enter name: ").strip()
        while not name.isalpha():
            print("Name must contain only letters.")
            name = input("Enter name: ").strip()
        record['name'] = name

        # Steps validation
        steps = input("Enter steps: ").strip()
        while not (steps.isdigit() and int(steps) >= 0):
            print("Steps must be a positive number.")
            steps = input("Enter steps: ").strip()
        record['steps'] = int(steps)

        # Calories validation
        calories = input("Enter calories: ").strip()
        while not (calories.isdigit() and int(calories) >= 0):
            print("Calories must be a positive number.")
            calories = input("Enter calories: ").strip()
        record['calories'] = int(calories)

        # Hours slept validation
        hours = input("Enter hours slept: ").strip()
        while not (hours.isdigit() and 0 <= int(hours) <= 24):
            print("Hours slept must be between 0 and 24.")
            hours = input("Enter hours slept: ").strip()
        record['hours_slept'] = int(hours)

        records.append(record)
        print(" Record added successfully.")
  

    elif choice == '2':
        if not records:
            print("No records to display.")
        else:
            print(tabulate(records,headers="keys", tablefmt="grid"))
           


    elif choice == '3':
        avg = compute_average(records, 'steps')
        print(f"Average Steps: {avg:.2f}")

    elif choice == '4':
        top = top_record(records, metric_keys)
        if top:
            print("Top Record (highest sum):", top)
        else:
            print("No records found.")

    elif choice == '5':
        max_rec = max_record(records, 'steps')
        if max_rec:
            print("Max Steps Record:", max_rec)
        else:
            print("No records found.")

    elif choice == '6':
        min_rec = min_record(records,'steps')
        if min_rec:
            print("min",min_rec)
        else:
            print("No records found.")

    elif choice == '13':
        threshold = int(input("Enter steps threshold: "))

        # Step 1: Filter the records
        filtered = list(filter(lambda r: r['steps'] >= threshold, records))

        # Step 2: Map to extract (id, name)
        result = list(map(lambda r: (r['id'], r['name']), filtered))

        if result:
            print(f"\nRecords with steps >= {threshold}:")
            for rid, name in result:
                print(f"ID: {rid} | Name: {name}")
        else:
            print("No matching records.")




    elif choice == '34':
        rid = input("Enter record ID to search: ").strip()
        for r in records:
            if r['id'] == rid:
                print("\nID | Name | Date | Steps | Calories | Hours Slept")
                print("Record found:", r)
                break
        else:
            print("Record not found.")
    elif choice == '7':
        ridd = input("Enter record ID to search: ").strip()
        filtered = [r for r in records if str(r['id']) == ridd]
        if filtered:
            print("\nRecord found:\n")
            print(tabulate(filtered, headers="keys", tablefmt="grid"))
        else:
            print("Record not found.")

    elif choice == '8':
        rid = input("Enter record ID to remove: ").strip()
        for r in records:
            if r['id'] == rid:
                records.remove(r)
                print("Record removed successfully.")
                break
            else:
                print("Record not found.")


    elif choice == '9':
        if records:  
            sorted_records = sorted(records, key=lambda r: r['steps'])
            print("\nRecords sorted by steps:")
            for r in sorted_records:
                print(r)
        else:
            print("No records available.")

    elif choice == '10':
        if records:
            reversed_records = list(reversed(records))
            print("\nRecords in reverse order:")
            print(tabulate(reversed_records,headers="keys",tablefmt="Grid"))
        else:
            print("No records available.")


    elif choice == '11':
        print("Exiting program. Goodbye!")
        break
 
    else:
        print("Invalid choice. Please try again.")
        print("Invalid Choice")
