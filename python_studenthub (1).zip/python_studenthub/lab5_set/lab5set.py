def getSetFromInput(name):
    while True:
        data = input(f"Enter {name} items separated by commas: ").strip()
        if data:
            return set(item.strip().title() for item in data.split(",") if item.strip())
        else:
            print(f"{name} cannot be empty, please enter again.")


def displaySetOperations(study, wellness, hobbies):
    print("\n--- EduWell Set Operations Results ---")
    print(f"Study Subjects: {study}")
    print(f"Wellness Activities: {wellness}")
    print(f"Hobbies: {hobbies}")

    unionResult = study.union(wellness).union(hobbies)
    print("\nUnion of all sets:", unionResult)

    intersectionResult = study.intersection(wellness).intersection(hobbies)
    print("Intersection of all sets:", intersectionResult if intersectionResult else "No common items")

    differenceStudyWellness = study.difference(wellness)
    print("Items in Study but not in Wellness:", differenceStudyWellness if differenceStudyWellness else "None")

    differenceHobbiesStudy = hobbies.difference(study)
    print("Items in Hobbies but not in Study:", differenceHobbiesStudy if differenceHobbiesStudy else "None")

    symmetricDifferenceStudyWellness = study.symmetric_difference(wellness)
    print("Symmetric Difference (Study vs Wellness):", symmetricDifferenceStudyWellness)

    isSubset = wellness.issubset(study)
    print("Is Wellness a subset of Study?", "Yes" if isSubset else "No")

    isSuperset = study.issuperset(hobbies)
    print("Is Study a superset of Hobbies?", "Yes" if isSuperset else "No")


def main():
    print("Welcome to EduWell Student Wellness Set Manager")

    study = getSetFromInput("your study subjects")
    wellness = getSetFromInput("your wellness activities")
    hobbies = getSetFromInput("your hobbies")

    displaySetOperations(study, wellness, hobbies)

    while True:
        choice = input("\nDo you want to add more items to any set? (study/wellness/hobbies/exit): ").strip().lower()
        if choice == "study":
            study.update(getSetFromInput("additional study subjects"))
        elif choice == "wellness":
            wellness.update(getSetFromInput("additional wellness activities"))
        elif choice == "hobbies":
            hobbies.update(getSetFromInput("additional hobbies"))
        elif choice == "exit":
            print("Exiting EduWell Set Manager. Stay productive and healthy!")
            break
        else:
            print("Invalid choice, please enter again.")
            continue

        displaySetOperations(study, wellness, hobbies)


if __name__ == "__main__":
    main()
