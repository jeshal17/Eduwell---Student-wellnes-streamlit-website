# ===== fitness_utils.py =====

def compute_average(records, key):
    """Compute average of a numeric field"""
    if not records:
        return 0
    return sum(record[key] for record in records) / len(records)

def top_record(records, keys):
    """Return the record with highest sum of numeric fields"""
    if not records:
        return None
    return max(records, key=lambda r: sum(r[k] for k in keys))

def max_record(records, key):
    """Return the record with min and max value for a field"""
    if not records:
        return None
    return max(records, key=lambda r: r[key])

def min_record(records, key):
    """Return the record with min and max value for a field"""
    if not records:
        return None
    return min (records, key=lambda r: r[key])

 
records = [
    {'name': 'John', 'steps': 7000},
    {'name': 'Alice', 'steps': 4000},
    {'name': 'Bob', 'steps': 9000}
]

# Steps >= 5000
active = list(filter(lambda r: r['steps'] >= 5000, records))
names = list(map(lambda r: r['name'], active))
print("Active users:", names)
