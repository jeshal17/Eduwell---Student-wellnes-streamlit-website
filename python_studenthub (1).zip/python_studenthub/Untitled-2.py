# -------------------------------
# Fitness Tracker Data Analysis (Menu Driven)
# -------------------------------

# User-defined functions
def compute_average(records, key):
    """Compute average of a numeric attribute in all records"""
    if not records:
        return 0
    total = sum(record[key] for record in records)
    return total / len(records)

def top_record(records, keys):
    """Return record with highest combined value of given keys"""
    if not records:
        return None
    return max(records, key=lambda r: sum(r[k] for k in keys))

# Main program
records = []
metric_keys = ['steps', 'calories', 'hours_slept']

while True:
    print("\n--- Fitness Tracker Menu ---")
    print("1. Input Records")
    print("2. Display All Records")
    print("3. Show Top Record (Combined Metric)")
    print("4. Compute Average Steps")
    print("5. Filter Records by Steps Threshold")
    print("6. Show Names in Uppercase (Lambda/Map)")
    print("7. Exit")
    
    choice = input("Enter your choice (1-7): ")
    
    if choice == '1':
        num_records = int(input("Enter number of records to input (5-10): "))
        for i in range(num_records):
            print(f"\nRecord {i+1}:")
            record = {}
            record['name'] = input("Name: ")
            record['steps'] = int(input("Steps walked: "))
            record['calories'] = int(input("Calories burned: "))
            record['hours_slept'] = float(input("Hours slept: "))
            records.append(record)
        print(f"{num_records} records added successfully!")

    elif choice == '2':
        if not records:
            print("No records available.")
        else:
            print("\n--- All Records ---")
            for r in records:
                print(f"{r['name']:10} | Steps: {r['steps']:5} | Calories: {r['calories']:5} | Sleep: {r['hours_slept']:4}")

    elif choice == '3':
        top = top_record(records, metric_keys)
        if top:
            print("\n--- Top Record (Combined Metric) ---")
            print(f"{top['name']} -> Steps: {top['steps']}, Calories: {top['calories']}, Sleep: {top['hours_slept']}")
        else:
            print("No records available.")

    elif choice == '4':
        avg_steps = compute_average(records, 'steps')
        print(f"\nAverage Steps: {avg_steps:.2f}")

    elif choice == '5':
        if not records:
            print("No records available.")
        else:
            threshold = int(input("Enter steps threshold: "))
            filtered = [r for r in records if r['steps'] >= threshold]
            print(f"\n--- Records with Steps >= {threshold} ---")
            for r in filtered:
                print(f"{r['name']:10} | Steps: {r['steps']}")
            if not filtered:
                print("No records meet the threshold.")

    elif choice == '6':
        names_upper = list(map(lambda r: r['name'].upper(), records))
        print(f"\n--- Names in Uppercase ---")
        print(names_upper)

    elif choice == '7':
        print("Exiting program. Goodbye!")
        break

    else:
        print("Invalid choice! Please enter 1-7.")
